package com.kochchi.controller;

import com.kochchi.config.Config;
import com.kochchi.model.Train;
import com.kochchi.service.TrainServiceImpl;
import com.kochchi.service.SessionServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/train")
@CrossOrigin(origins = Config.allowedOrigin)
public class TrainController {

    @Autowired
    TrainServiceImpl trainService = new TrainServiceImpl();

    @Autowired
    SessionServiceImpl sessionService = new SessionServiceImpl();


    // GET all the Train items in the database.
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Train>> getAllTrainWithAuth() {

        return new ResponseEntity<>(TrainService.findAllTrain(), HttpStatus.OK);
    }

    // GET a Train buy its date.
    @RequestMapping(value = "/date/{date}", method = RequestMethod.GET)
    public ResponseEntity<Train> getTrainByDate(@RequestHeader("Authentication") long authKey, @PathVariable("date") Date date) {
        if (sessionService.authenticate(authKey)) {
            return new ResponseEntity<>(TrainService.findById(date), HttpStatus.OK);
        }
        else {
            return new ResponseEntity<>(new Train(), HttpStatus.UNAUTHORIZED);
        }

    }

    // FIND a Train item by its time.
    @RequestMapping(value = "/time/{time}", method = RequestMethod.GET)
    public ResponseEntity<List<Train>> getTrainByName(@RequestHeader("Authentication") long authKey, @PathVariable Time time) {
        return new ResponseEntity<>(TrainService.findTrainContainingName(time), HttpStatus.OK);
    }




}

package com.kochchi.service;

import com.kochchi.model.train;
import com.kochchi.repository.trainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service("trainService")
@Transactional
public class trainServiceImpl implements trainService {
    @Autowired
    private trainRepository trainRepository;

    private static List<train> trainItems;

    @Override
    public train findById(String fId) {
        return trainRepository.findtrainByFId(fId);
    }

    @Override
    public train findByName(String name) {
        return trainRepository.findtrainByDate(date);
    }

    @Override
    public List<train> findtrainContainingName(String name) {
        Iterable<train> trainIterable = trainRepository.findtrainByNameContaining(name);
        List<train> trainList = new ArrayList<>();

        trainIterable.forEach(trainList::add);
        return trainList;
    }

    @Override
    public double getPriceOf(String fId) {
        train train = trainRepository.findtrainByFId(fId);
        double price = -1;

        if (train != null) {
            price = train.getPrice();
        }

        return price;
    }

    public void savetrain(train train) {
        trainRepository.save(train);
    }

    @Override
    public void updatetrain(train trainUpdate) {
        train trainExisting = findByName(trainUpdate.getName());

        // update the item we retrieved.
        // DON'T update the fId.
        if (trainExisting != null) {
            trainExisting.setIngredients(trainUpdate.getIngredients());
            trainExisting.setPrice(trainUpdate.getPrice());
            trainExisting.setPrice(trainUpdate.getPrice());

            savetrain(trainExisting);
        }
    }

    @Override
    public void deletetrainById(String name) {
        trainRepository.deletetrainByName(name);
    }

    @Override
    public List<train> findAlltrain() {
        return trainRepository.findAll();
    }


    @Override
    public boolean istrainExist(train train) {
        return trainRepository.existsById(train.getfId());
    }
}

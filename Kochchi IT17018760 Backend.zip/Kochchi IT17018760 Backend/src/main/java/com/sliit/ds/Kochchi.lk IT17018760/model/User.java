package com.kochchi.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import javax.validation.constraints.NotEmpty;

@Document(collection = "user")
public class User {


    @NotEmpty
    private String email;

    @NotEmpty
    private String NIC;

    @NotEmpty
    private String name;

    @NotEmpty
    private int mobileNumber;

    @NotEmpty
    private String address;

    private long password;

    public User() { }

    public long getUid() {
        return uid;
    }

    public void setUid(long uid) {
        this.uid = uid;
    }

     public long getNIC() {
            return NIC;
        }

        public void setNIC(long NIC) {
            this.NICid = NIC;
        }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMobileNumber() {
        return this.mobileNumber;
    }

    public void setMobileNumber(int mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }

    public long getPassword() {
        return password;
    }

    public void setPassword(long password) {
        this.password = password;
    }
}

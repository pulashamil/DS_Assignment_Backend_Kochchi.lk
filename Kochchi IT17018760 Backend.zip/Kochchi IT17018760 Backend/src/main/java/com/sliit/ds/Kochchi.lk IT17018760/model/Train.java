package com.kochchi.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.Map;

@Document(collection = "Train")
public class Train {

    @Id
    private Date date;    
    private Time Time;
    private String NIC;
    private int noOfSeats;
    private int servingCount;  
    private ArrayList<String> ingredients;


    public Train() { }

    public Train(String Time, int servingCount, ArrayList<String> ingredients, double price) {
        this.date = "FD" + Long.toString(Time.hashCode());
        this.Time = Time;
        this.servingCount = servingCount;
        this.ingredients = ingredients;
        this.price = price;
    }

    public Train(Map<String, Object> payload) {
        this.Time = payload.get("Time").toString();
        this.date = "FD" + Long.toString(this.Time.hashCode());
        this.servingCount = Integer.parseInt(payload.get("servingCount").toString());
        this.price = Double.parseDouble(payload.get("price").toString());
        this.ingredients = getIngredientsList(payload.get("ingredients"));
    }

    public String getdate() {
        return date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String Time) {
        this.Time = Time;
    }


     public int getnoOFSeats() {
            return noOFSeats;
        }

        public void setnoOFSeats(int noOFSeats) {
            this.noOFSeats = noOFSeats;
        }

    public int getServingCount() {
        return servingCount;
    }

    public void setServingCount(int servingCount) {
        this.servingCount = servingCount;
    }

    public ArrayList<String> getIngredients() {
        return ingredients;
    }

    public void setIngredients(ArrayList<String> ingredients) {
        this.ingredients = ingredients;
    }



    // we are dealing with a json array here.
    public ArrayList<String> getIngredientsList(Object ingredients) {
        ArrayList<String> ingredientsList = new ArrayList<>();
        String ingredientsStr = ingredients.toString();


        String[] ingredientsArr = ingredientsStr.split(",");

        for(String ingredient: ingredientsArr) {



            ingredientsList.add(ingredient);
        }

        return ingredientsList;
    }
}

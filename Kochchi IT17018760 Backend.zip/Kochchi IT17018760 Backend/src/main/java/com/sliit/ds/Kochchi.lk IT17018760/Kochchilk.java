package com.kochchi;

import com.kochchi.model.Train;
import com.kochchi.model.User;
import com.kochchi.repository.TrainRepository;
import com.kochchi.repository.UserRepository;
import com.kochchi.service.TrainService;
import com.kochchi.service.TrainServiceImpl;
import com.kochchi.service.UserService;
import com.kochchi.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;

@SpringBootApplication
public class Kochchilk implements CommandLineRunner{

    @Autowired
	private TrainRepository TrainRepository;

    @Autowired
	private UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(Kochchoilk.class, args);
	}

    @Override
    public void run(String... args) throws Exception {

        // we are adding a few Train items and a user so that the demo is functional with data.
        Train Kandy = new Train();
        ArrayList<String> place = new ArrayList<>();

        ingredients.add("Badulla");
        ingredients.add("Fort");
        ingredients.add("Peradeniya");
        ingredients.add("Haputhale");
        Kandy.setName("Ella");
        Kandy.setPrice(450);
        Kandy.setClass(1);
        Kandy.setServingCount(1);



        Train Fort = new Train();


        Fort.setName("Fort");
        Fort.setIngredients(place);
        Fort.setServingCount(1);
        Fort.setPrice(350);
        Fort.setClass(1);

        // save the 2 Train items.
        TrainRepository.save(Fort);
        TrainRepository.save(Fort);


        // add an admin account.
        User admin = new User();
        admin.setPassword(92668751);    // hash code of "admin" as a password. Type "admin" for password when logging in.
        admin.setMobileNumber(0);
        admin.setAddress("Server");
        admin.setUid(1);
        admin.setName("Admin");
        admin.setEmail("pula@gmail.com");

        // save the admin account.
        userRepository.save(admin);
    }
}

package com.kochchi.service;

import com.kochchi.model.train;

import java.util.List;

public interface trainService {

    train findByDate(Date date);

    train findByTime(Time time);

    List<train> findtrainContainingName(Date date);

    double getPriceOf(cost cost);

    void savetrain(train train);

    void updatetrain(train trainUpdate);

    void CancelTrainByNIC(String nic);

    List<train> findAlltrain();

    public boolean istrainExist(train train);
}

package com.Kochchi.config;

public class Config {

    public static final String allowedOrigin = "http://localhost:8080";

    public static String getAllowedOrigin() {
        return allowedOrigin;
    }
}

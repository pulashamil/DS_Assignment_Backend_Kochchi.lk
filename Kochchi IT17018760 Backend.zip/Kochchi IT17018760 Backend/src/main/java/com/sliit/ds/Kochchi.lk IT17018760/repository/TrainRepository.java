package com.kochchi.repository;

import com.kochchi.model.Food;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TrainRepository extends MongoRepository<Food, String> {

    Train FindTrainByDate(Date date);
    Train findTrainByTime(Time time);
    Train noOfSeats(int seats)
    List<Train> FindTrainByDate(Date date);


    void CancelTicketByNIC(String NIC);
    void CancelTicketByDate(Date date);
}
